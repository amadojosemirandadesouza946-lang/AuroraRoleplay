Aurora Roleplay - Android project skeleton
========================================

Conteúdo:
- Projeto Android Studio (skeleton) em Kotlin.
- Package: com.aurora.roleplay
- Imagem de splash incluída: res/drawable/splash_image.png
- Server IP embutido: 188.165.192.24:5644
- SharedPreferences usado para 'data própria' (armazenamento local).

Como compilar (Android Studio):
1. Abra este diretório no Android Studio.
2. Aguarde a sincronização do Gradle.
3. Build -> Build Bundle(s) / APK(s) -> Build APK(s).
4. O APK será gerado em app/build/outputs/apk/

Como compilar (linha de comando com gradle wrapper - se você configurar gradle):
1. Instale o Android SDK e configure ANDROID_HOME.
2. Execute: ./gradlew assembleDebug  (pode precisar de ajustes)

Observações:
- Este projeto é um esqueleto. Não inclui permissões especiais ou integração real com clientes SAMP móveis.
- O botão 'Conectar' tenta abrir um intent com esquema 'samp://IP:PORT' — muitos dispositivos não possuem um handler para isso.
- Para gerar um APK pronto para distribuição, assine o APK (release) com sua chave.